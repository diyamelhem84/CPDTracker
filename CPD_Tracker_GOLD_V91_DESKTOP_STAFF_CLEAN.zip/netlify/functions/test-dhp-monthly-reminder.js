
export default async () => {
  return new Response(JSON.stringify({
    message: "To test the monthly reminder, open /.netlify/functions/dhp-monthly-reminder after setting environment variables."
  }), { headers: { "Content-Type": "application/json" } });
};
