
// CPD Tracker V53 - Confirm Password Reset
// Required Netlify env vars: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY

async function supabaseFetch(path, options = {}) {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
  return fetch(`${url}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      ...(options.headers || {})
    }
  });
}

function normalize(s){ return String(s || "").trim().toLowerCase(); }

export default async (request) => {
  try {
    if (request.method !== "POST") {
      return new Response(JSON.stringify({ ok:false, error:"POST required" }), { status:405, headers:{ "Content-Type":"application/json" }});
    }

    const { identifier, code, newPassword } = await request.json();
    const id = normalize(identifier);
    const resetCode = String(code || "").trim();
    const password = String(newPassword || "");

    if (!id || !resetCode || !password) {
      return new Response(JSON.stringify({ ok:false, error:"All fields are required" }), { status:400, headers:{ "Content-Type":"application/json" }});
    }
    if (password.length < 4) {
      return new Response(JSON.stringify({ ok:false, error:"Password must be at least 4 characters" }), { status:400, headers:{ "Content-Type":"application/json" }});
    }

    const staffRes = await supabaseFetch("staff_cpd?select=*");
    if (!staffRes.ok) throw new Error(`Supabase query failed: ${staffRes.status}`);
    const staffList = await staffRes.json();

    const staff = staffList.find(s =>
      normalize(s.username) === id ||
      normalize(s.email) === id ||
      normalize(s.email_address) === id ||
      normalize(s.work_email) === id ||
      normalize(s.personal_email) === id
    );

    if (!staff || String(staff.reset_code || "") !== resetCode) {
      return new Response(JSON.stringify({ ok:false, error:"Invalid reset code" }), { status:400, headers:{ "Content-Type":"application/json" }});
    }

    if (!staff.reset_code_expires || new Date(staff.reset_code_expires).getTime() < Date.now()) {
      return new Response(JSON.stringify({ ok:false, error:"Reset code expired. Please request a new code." }), { status:400, headers:{ "Content-Type":"application/json" }});
    }

    const updateRes = await supabaseFetch(`staff_cpd?id=eq.${encodeURIComponent(staff.id)}`, {
      method: "PATCH",
      body: JSON.stringify({
        password,
        reset_code: null,
        reset_code_expires: null,
        updated_at: new Date().toISOString().slice(0,10)
      })
    });

    if (!updateRes.ok) {
      const body = await updateRes.text();
      throw new Error(`Could not update password: ${body}`);
    }

    return new Response(JSON.stringify({ ok:true, updated:true }), { headers:{ "Content-Type":"application/json" }});
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ ok:false, error:error.message }), { status:500, headers:{ "Content-Type":"application/json" }});
  }
};
