export const config = { schedule: "0 6 * * *" };

export default async () => {
  return new Response(JSON.stringify({
    ok: false,
    message: "Configure SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, EMAILJS_PUBLIC_KEY, ADMIN_EMAIL in Netlify environment variables, then replace this placeholder with the full reminder function if needed."
  }), { headers: { "Content-Type": "application/json" } });
};
