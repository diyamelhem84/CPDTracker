
// CPD Tracker V53 - Request Password Reset
// Required Netlify env vars:
// SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, EMAILJS_PUBLIC_KEY, ADMIN_EMAIL

async function supabaseFetch(path, options = {}) {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
  return fetch(`${url}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      ...(options.headers || {})
    }
  });
}

function normalize(s){ return String(s || "").trim().toLowerCase(); }
function staffName(staff){ return staff.full_name || staff.fullName || staff.name || staff.username || "Staff"; }
function staffEmail(staff){ return staff.email || staff.email_address || staff.work_email || staff.personal_email || ""; }

async function sendEmail({toEmail, name, subject, message, htmlMessage}) {
  const service_id = process.env.EMAILJS_SERVICE_ID;
  const template_id = process.env.EMAILJS_TEMPLATE_ID;
  const user_id = process.env.EMAILJS_PUBLIC_KEY;
  const accessToken = process.env.EMAILJS_PRIVATE_KEY;
  if (!service_id || !template_id || !user_id) throw new Error("Missing EmailJS variables");
  if (!accessToken) throw new Error("Missing EMAILJS_PRIVATE_KEY in Netlify Environment Variables");

  const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      service_id,
      template_id,
      user_id,
      accessToken,
      template_params: {
        to_email: toEmail,
        admin_email: toEmail,
        name,
        subject,
        message,
        html_message: htmlMessage
      }
    })
  });
  if (!res.ok) throw new Error(`EmailJS failed: ${res.status} ${await res.text()}`);
}

export default async (request) => {
  try {
    if (request.method !== "POST") {
      return new Response(JSON.stringify({ ok:false, error:"POST required" }), { status:405, headers:{ "Content-Type":"application/json" }});
    }

    const { identifier } = await request.json();
    const id = normalize(identifier);
    if (!id) {
      return new Response(JSON.stringify({ ok:false, error:"Username or email is required" }), { status:400, headers:{ "Content-Type":"application/json" }});
    }

    const staffRes = await supabaseFetch("staff_cpd?select=*");
    if (!staffRes.ok) throw new Error(`Supabase query failed: ${staffRes.status}`);
    const staffList = await staffRes.json();

    const staff = staffList.find(s =>
      normalize(s.username) === id ||
      normalize(s.email) === id ||
      normalize(s.email_address) === id ||
      normalize(s.work_email) === id ||
      normalize(s.personal_email) === id
    );

    // Security: do not reveal if username exists.
    if (!staff) {
      return new Response(JSON.stringify({ ok:true, sent:true }), { headers:{ "Content-Type":"application/json" }});
    }

    const code = String(Math.floor(100000 + Math.random() * 900000));
    const expires = new Date(Date.now() + 30 * 60 * 1000).toISOString();

    const updateRes = await supabaseFetch(`staff_cpd?id=eq.${encodeURIComponent(staff.id)}`, {
      method: "PATCH",
      body: JSON.stringify({
        reset_code: code,
        reset_code_expires: expires
      })
    });
    if (!updateRes.ok) {
      const body = await updateRes.text();
      throw new Error(`Could not save reset code. Run SQL_V53_LOGIN_SYSTEM.sql first. ${body}`);
    }

    const email = staffEmail(staff);
    const target = email && email.includes("@") ? email : process.env.ADMIN_EMAIL;
    if (!target || !target.includes("@")) throw new Error("No valid staff email or ADMIN_EMAIL found");
    const recipientNote = (email && email.includes("@"))
      ? "directly to the staff registered email"
      : "to ADMIN_EMAIL because no staff email is saved";

    const subject = "CPD Tracker Password Reset Code";
    const message = `Password reset requested for ${staffName(staff)} (${staff.username || ""}).\n\nReset code: ${code}\nExpires in: 30 minutes\n\nThis code was sent ${recipientNote}.`;
    const htmlMessage = `
      <div style="font-family:Arial,sans-serif;color:#0f172a;">
        <h2>CPD Tracker Password Reset</h2>
        <p>Password reset requested for <b>${staffName(staff)}</b> (${staff.username || ""}).</p>
        <div style="font-size:28px;font-weight:800;letter-spacing:4px;padding:14px 18px;background:#eef2ff;border-radius:12px;display:inline-block;">${code}</div>
        <p>This code expires in <b>30 minutes</b>.</p>
      </div>`;

    await sendEmail({ toEmail: target, name: staffName(staff), subject, message, htmlMessage });

    return new Response(JSON.stringify({ ok:true, sent:true }), { headers:{ "Content-Type":"application/json" }});
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ ok:false, error:error.message }), { status:500, headers:{ "Content-Type":"application/json" }});
  }
};
