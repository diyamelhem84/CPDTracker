
// CPD Tracker V51 - Smart Staged DHP Email Reminders
// Sends ONE summary email only when staff newly reach one of these stages:
// 120 days, 90 days, 60 days, 30 days before DHP expiry.
// Each staff is sent only once per stage using last_reminder_stage.
// Schedule: daily at 06:00 UTC so it can catch exact stages without needing login.
// Required Netlify Environment Variables:
// SUPABASE_URL
// SUPABASE_SERVICE_ROLE_KEY
// EMAILJS_SERVICE_ID
// EMAILJS_TEMPLATE_ID
// EMAILJS_PUBLIC_KEY
// ADMIN_EMAIL

export const config = { schedule: "0 6 * * *" };

async function supabaseFetch(path, options = {}) {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
  return fetch(`${url}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      ...(options.headers || {})
    }
  });
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const d = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  return Math.ceil((d - new Date()) / 86400000);
}

function getReminderStage(days) {
  // Stage windows are intentionally slightly tolerant because a daily scheduled job
  // can run at different UTC/local times. Each staff still receives only one email per stage.
  if (days <= 120 && days > 90) return "120d";
  if (days <= 90 && days > 60) return "90d";
  if (days <= 60 && days > 30) return "60d";
  if (days <= 30 && days > 0) return "30d";
  return null;
}

function stageLabel(stage) {
  return {
    "120d": "120 days / 4 months",
    "90d": "90 days / 3 months",
    "60d": "60 days / 2 months",
    "30d": "30 days / 1 month"
  }[stage] || stage;
}

function staffName(staff) {
  return staff.full_name || staff.fullName || staff.name || staff.username || "Unnamed staff";
}

function staffArea(staff) {
  return staff.area || staff.department || "Unassigned";
}

function htmlEscape(s) {
  return String(s ?? "")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;");
}

function formatRows(list) {
  if (!list.length) return "<tr><td colspan='5'>None</td></tr>";
  return list.map(x => `
    <tr>
      <td>${htmlEscape(x.name)}</td>
      <td>${htmlEscape(x.area)}</td>
      <td>${htmlEscape(x.expiry)}</td>
      <td>${x.days} days</td>
      <td>${stageLabel(x.stage)}</td>
    </tr>
  `).join("");
}

async function sendEmail({ rowsByStage, total }) {
  const service_id = process.env.EMAILJS_SERVICE_ID;
  const template_id = process.env.EMAILJS_TEMPLATE_ID;
  const user_id = process.env.EMAILJS_PUBLIC_KEY;
  const adminEmail = process.env.ADMIN_EMAIL;

  if (!service_id || !template_id || !user_id || !adminEmail) {
    throw new Error("Missing EmailJS environment variables");
  }

  const allRows = [
    ...rowsByStage["120d"],
    ...rowsByStage["90d"],
    ...rowsByStage["60d"],
    ...rowsByStage["30d"]
  ];

  const subject = `CPD Tracker – DHP Staged Reminder (${total} staff)`;

  const htmlMessage = `
    <div style="font-family:Arial,sans-serif;color:#0f172a;">
      <h2 style="color:#1d4ed8;">CPD Tracker – DHP Staged Reminder</h2>
      <p>This email includes staff who newly reached one of the DHP renewal reminder stages.</p>

      <h3 style="color:#2563eb;">120 days / 4 months</h3>
      <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%;">
        <tr><th>Name</th><th>Area</th><th>DHP Expiry</th><th>Remaining</th><th>Stage</th></tr>
        ${formatRows(rowsByStage["120d"])}
      </table>

      <h3 style="color:#7c3aed;">90 days / 3 months</h3>
      <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%;">
        <tr><th>Name</th><th>Area</th><th>DHP Expiry</th><th>Remaining</th><th>Stage</th></tr>
        ${formatRows(rowsByStage["90d"])}
      </table>

      <h3 style="color:#f97316;">60 days / 2 months</h3>
      <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%;">
        <tr><th>Name</th><th>Area</th><th>DHP Expiry</th><th>Remaining</th><th>Stage</th></tr>
        ${formatRows(rowsByStage["60d"])}
      </table>

      <h3 style="color:#991b1b;">30 days / 1 month</h3>
      <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%;">
        <tr><th>Name</th><th>Area</th><th>DHP Expiry</th><th>Remaining</th><th>Stage</th></tr>
        ${formatRows(rowsByStage["30d"])}
      </table>

      <p><b>Action:</b> Please follow up and update CPD Tracker once renewal is completed.</p>
    </div>
  `;

  const textMessage = [
    "CPD Tracker – DHP Staged Reminder",
    "",
    ...allRows.map(x => `- ${x.name} (${x.area}) | expiry: ${x.expiry} | ${x.days} days | ${stageLabel(x.stage)}`)
  ].join("\n");

  const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      service_id,
      template_id,
      user_id,
      template_params: {
        to_email: adminEmail,
        admin_email: adminEmail,
        subject,
        message: textMessage,
        html_message: htmlMessage,
        total_count: total,
        count_120: rowsByStage["120d"].length,
        count_90: rowsByStage["90d"].length,
        count_60: rowsByStage["60d"].length,
        count_30: rowsByStage["30d"].length
      }
    })
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`EmailJS failed: ${response.status} ${body}`);
  }
}

async function updateStaffStage(staffId, stage) {
  const res = await supabaseFetch(`staff_cpd?id=eq.${encodeURIComponent(staffId)}`, {
    method: "PATCH",
    body: JSON.stringify({
      last_reminder_stage: stage,
      last_email_sent: new Date().toISOString().slice(0, 10)
    })
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Failed to update staff reminder stage: ${res.status} ${body}`);
  }
}

export default async () => {
  try {
    const staffRes = await supabaseFetch("staff_cpd?active=eq.true&role=eq.staff&select=*");
    if (!staffRes.ok) throw new Error(`Supabase staff query failed: ${staffRes.status}`);
    const staffList = await staffRes.json();

    const rowsByStage = { "120d": [], "90d": [], "60d": [], "30d": [] };
    const updates = [];

    for (const staff of staffList) {
      const expiry = staff.dhp_expiry || staff.dhpExpiry;
      const days = daysUntil(expiry);
      if (days === null || days <= 0) continue;

      const stage = getReminderStage(days);
      if (!stage) continue;

      // Do not send the same stage twice for same staff.
      if (staff.last_reminder_stage === stage) continue;

      // Reset scenario: if staff renewed and later enters a new cycle, the DHP expiry date changes.
      // Existing last_reminder_stage won't block stages that are different.
      const row = {
        id: staff.id,
        name: staffName(staff),
        area: staffArea(staff),
        expiry,
        days,
        stage
      };

      rowsByStage[stage].push(row);
      updates.push({ id: staff.id, stage });
    }

    const total = Object.values(rowsByStage).reduce((sum, rows) => sum + rows.length, 0);

    if (total === 0) {
      return new Response(JSON.stringify({
        ok: true,
        sent: false,
        reason: "No new staff reached a reminder stage today"
      }), { headers: { "Content-Type": "application/json" } });
    }

    await sendEmail({ rowsByStage, total });

    // Only update after successful email send.
    for (const item of updates) {
      await updateStaffStage(item.id, item.stage);
    }

    return new Response(JSON.stringify({
      ok: true,
      sent: true,
      total,
      stages: {
        "120d": rowsByStage["120d"].length,
        "90d": rowsByStage["90d"].length,
        "60d": rowsByStage["60d"].length,
        "30d": rowsByStage["30d"].length
      }
    }), { headers: { "Content-Type": "application/json" } });

  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ ok: false, error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
