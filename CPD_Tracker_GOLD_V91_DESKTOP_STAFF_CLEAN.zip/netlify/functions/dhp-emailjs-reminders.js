
exports.config = { schedule: "0 6 * * *" };

const SERVICE_ID = "service_s9chwmg";
const TEMPLATE_ID = "template_nuuls8p";
const PUBLIC_KEY = "WZnA62jfcrpLulv3c";
const ADMIN_EMAIL = "d.milhem@westbaymedicare.com";

function daysBetween(expiry){
  const today = new Date();
  const exp = new Date(expiry);
  if (isNaN(exp)) return null;
  return Math.ceil((exp - today)/(1000*60*60*24));
}
function stage(days){
  return [120,90,60,30].includes(days) ? String(days) : null;
}
exports.handler = async function(){
  try{
    const url = process.env.SUPABASE_URL || process.env.CPD_SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if(!url || !key) return {statusCode:200, body:"Missing Supabase env vars. Client-side reminders still work."};

    const res = await fetch(`${url}/rest/v1/staff_cpd?select=*`, {headers:{apikey:key, Authorization:`Bearer ${key}`}});
    const users = await res.json();
    let sent = 0;

    for(const u of users || []){
      if(u.role !== "staff" || !u.dhp_expiry) continue;
      if(String(u.dhp_license||"").trim().toUpperCase().startsWith("TN")) continue;
      const d = daysBetween(u.dhp_expiry);
      const st = stage(d);
      if(!st) continue;

      const logKey = `dhp-email-${u.id}-${st}`;
      const check = await fetch(`${url}/rest/v1/notifications?select=id&type=eq.DHP Email ${st}&user_id=eq.${u.id}`, {headers:{apikey:key, Authorization:`Bearer ${key}`}});
      const existing = await check.json();
      if(existing && existing.length) continue;

      await fetch("https://api.emailjs.com/api/v1.0/email/send", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          service_id:SERVICE_ID,
          template_id:TEMPLATE_ID,
          user_id:PUBLIC_KEY,
          template_params:{
            to_email:ADMIN_EMAIL,
            staff_name:u.full_name || u.username || "Staff",
            days_left:String(d),
            dhp_expiry:u.dhp_expiry,
            message:`${u.full_name || u.username || "Staff"} DHP license expires in ${d} days. Expiry: ${u.dhp_expiry}`
          }
        })
      });

      await fetch(`${url}/rest/v1/notifications`, {
        method:"POST",
        headers:{apikey:key, Authorization:`Bearer ${key}`, "Content-Type":"application/json", Prefer:"return=minimal"},
        body:JSON.stringify({user_id:u.id, username:"system", type:`DHP Email ${st}`, message:`DHP reminder email sent to admin for ${u.full_name || u.username}`, status:"read", created_at:new Date().toISOString()})
      });
      sent++;
    }
    return {statusCode:200, body:JSON.stringify({ok:true, sent})};
  }catch(e){
    return {statusCode:500, body:e.message || "failed"};
  }
};
